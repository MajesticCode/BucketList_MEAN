Bucket List

This is a working in progress Coding Dojo project created by using MEAN (Mongodb, Express, Angular, and Node.js).

The feature of this project is stated in the wireframe MEANbucketlist.png.

Eric

